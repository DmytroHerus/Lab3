﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdTask
{
    public class Airplane : Vehicle
    {
        public int WingsLenght { get; set; }
    }
}
